How to use this:

1. Download and install the official Xbox 360 Controller driver: (not needed for windows>=8)
	http://www.microsoft.com/hardware/en-us/d/xbox-360-controller-for-windows
2. Run ScpDriver.exe
3. Click install, wait until it finishes to close it
4. Run XOutput and set up your controller mappings (gear icon)
5. Click "Start"